F-ucking
D-umb
P-eople

Full form of FDP Client.


This is a joke repo to shit talk on fdp if you didn't notice already
