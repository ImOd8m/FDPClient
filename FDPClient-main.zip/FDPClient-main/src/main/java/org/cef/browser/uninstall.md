## Thank you for uninstalling FDP Client!
You are now free from the pain of using FDP Client, congratulations!
