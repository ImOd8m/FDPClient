package org.cef.browser.scheme;

/**
 * @author montoyo
 */
public enum SchemePreResponse {
    NOT_HANDLED,
    HANDLED_CONTINUE,
    HANDLED_CANCEL
}
